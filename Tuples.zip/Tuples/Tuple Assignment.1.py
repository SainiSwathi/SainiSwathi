#1. Write a Python program to find the number of times 4 appears in the tuple. 

#Input: tuplex = (2, 4, 5, 6, 2, 3, 4, 4, 7)

tup = (2, 4, 5, 6, 2, 3, 4, 4, 7)

appers_in_4 = tup.count(4)

print(f'The number 4 appears {appers_in_4} times in the tup.')


